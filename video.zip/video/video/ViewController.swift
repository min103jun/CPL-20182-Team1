//
//  ViewController.swift
//  video
//
//  Created by 김도한 on 29/10/2018.
//  Copyright © 2018 김도한. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
   
        
    
    var player: AVPlayer!
    var playerLayer: AVPlayerLayer!
    
    var isPlaying = false
    var isLandscape = false

    @IBOutlet weak var videoView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //uuid
        let retrievedString : String? = KeychainWrapper.standard.string(forKey: "UUID")
        //retrievedString = uuid saved as tag "UUID" return
        if retrievedString == nil{
            let uuid = NSUUID().uuidString // uuid = uuid
            print(uuid)
            let saveSuccessful : Bool = KeychainWrapper.standard.set(uuid, forKey :"UUID") //uuid save name = "UUID"
            if(saveSuccessful == false){
                print("keychain save failed")
                //dd
            }
            else{
                print("keychain save success")
                //video play

            }
        
        }
        let uuid = NSUUID().uuidString
        print(uuid)
      
        let path = Bundle.main.path(forResource: "sample", ofType: "mp4")
        let url = URL(fileURLWithPath: path!)
        player = AVPlayer(url: url)
        
        playerLayer = AVPlayerLayer(player: player)
        videoView.layer.addSublayer(playerLayer)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer.frame = videoView.bounds
    }

    @IBAction func playPauseButton(_ sender: UIButton) {
        if isPlaying{
            player.pause()
            sender.setTitle("Play", for: .normal)
        }
        else{
            player.play()
            sender.setTitle("pause", for: .normal)
        }
        isPlaying = !isPlaying
    }
    
    @IBAction func forwardButton(_ sender: Any) {
        guard let duration = player.currentItem?.duration else{return}
        let currentTime = CMTimeGetSeconds(player.currentTime())
        let newTime = currentTime + 5.0
        
        if newTime < CMTimeGetSeconds(duration) - 5.0{
            let time : CMTime = CMTimeMake(Int64(newTime*1000), 1000)
            player.seek(to:time)
            
        }
    }
    @IBAction func backwardButton(_ sender: Any) {
        let currentTime = CMTimeGetSeconds(player.currentTime())
        var newTime = currentTime-5.0
        
        if newTime < 0{
            newTime = 0
        }
        let time : CMTime = CMTimeMake(Int64(newTime*1000), 1000)
        player.seek(to:time)
    }
    @IBAction func play05(_ sender: Any) {
        player.rate = 0.5
    }
    @IBAction func play10(_ sender: Any) {
        player.rate = 1.0
    }
    @IBAction func play12(_ sender: Any) {
        player.rate = 1.2
    }
    @IBAction func play16(_ sender: Any) {
        player.rate = 1.6
    }
    
    @IBAction func play20(_ sender: Any) {
        player.rate = 2.0
    }
    @IBAction func play30(_ sender: Any) {
        player.rate = 3.0
    }
    
   

    
    
}

